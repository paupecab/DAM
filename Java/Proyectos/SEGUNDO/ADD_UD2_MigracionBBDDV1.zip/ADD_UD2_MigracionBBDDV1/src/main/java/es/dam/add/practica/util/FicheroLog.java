package es.dam.add.practica.util;

//usamos log4j
public class FicheroLog {
}
