package es.dam.add.practica.modelo;

// 1 cliente puede hacer N pedidos;
// 1 pedido solo esta asociado a 1 cliente
public class Pedido {
}
