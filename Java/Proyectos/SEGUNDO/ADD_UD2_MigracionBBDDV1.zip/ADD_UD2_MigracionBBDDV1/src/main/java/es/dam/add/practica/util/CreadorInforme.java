package es.dam.add.practica.util;

//crea fichero.txt con los contadores finales
public class CreadorInforme {
}
