package es.dam.add.practica.servicio;

//lee de prac2 - transforma - escribe en prac2migra
//gestiona transaccion y rollback
public class ServicioMigracion {
}
