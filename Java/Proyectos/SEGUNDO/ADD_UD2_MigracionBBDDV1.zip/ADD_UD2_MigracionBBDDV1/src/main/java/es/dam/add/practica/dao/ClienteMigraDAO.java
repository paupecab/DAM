package es.dam.add.practica.dao;


//implementa JDBC para tabla Clientes
public class ClienteMigraDAO {
}
