package es.dam.add.practica.servicio;

//logica negocio --> carga  masiva y operaciones CRUD de prueba
public class GestionTienda {
}
