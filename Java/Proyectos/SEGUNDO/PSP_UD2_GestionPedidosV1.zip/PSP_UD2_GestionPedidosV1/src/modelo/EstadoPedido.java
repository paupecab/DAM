package modelo;

public enum EstadoPedido {
    PENDIENTE, PROCESANDO, ENVIADO
}
