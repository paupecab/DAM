## Requisitos para ejecutar el proyecto

:D - Asegúrate de tener el conector MySQL instalado en tu entorno.
:D - Puedes descargar el conector desde [este enlace](https://dev.mysql.com/downloads/connector/j/).
:D - Después de descargarlo, coloca el archivo `mysql-connector-java-8.0.33.jar` en la carpeta `libs` de tu proyecto (o en una carpeta que uses para dependencias externas).
:D - Añade el archivo al classpath de tu proyecto para que Java pueda acceder a las clases del conector.
